/*
 * Servo.h
 *
 *  Created on: Feb 19, 2022
 *      Author: Amr Mahgoub
 */

#ifndef SERVO_H_
#define SERVO_H_
#include"Dioo.h"
#include"delay.h"
void Servo_init();
void Possition_Zero(void);
void Possition_90(void);
void Possition_180(void);



#endif /* SERVO_H_ */
